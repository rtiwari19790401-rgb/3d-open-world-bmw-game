# M5 Open World

A 3D driving game that runs in the browser. Drive across an open world with cities, highways, countryside, mountains and sea. Take taxi passengers for money, then spend it on engine and turbo upgrades.

> **Status: early prototype.** The whole game is one HTML file. Some planned features (airports, trains, flyovers) are not in yet. See the [Roadmap](#roadmap).

**Play online:** after you turn on GitHub Pages (see [Put it on GitHub](#put-it-on-github)), the game is at `https://<your-username>.github.io/<your-repo>/`.

<!-- Add screenshots or a gameplay GIF here -->

## Features

### Open world

The map has three cities. Centro City is in the middle, Udyog Nagar is to the north-east, and Sagar Nagar is to the south-west. Each city has flat ground, a grid of roads that ends at the city edge, and buildings. Outside the cities there is countryside: desert to the east, spring meadows to the west, mountains to the north, and forest to the south. A ring of mountains surrounds the land, and the sea begins beyond it.

### Day, night and weather

The sun moves automatically. One full day takes about 10 minutes. The weather changes every 2 minutes: clear, rain, fog, snow or sandstorm. Rain and snow make the road slippery.

### Driving

The gearbox is manual, with reverse and six forward gears. There is no clutch pedal. Sport mode gives full engine power when on and 80% power when off. Drift mode makes the car slide more when you turn. There are three camera views: chase, interior (with a clear windscreen) and orbit. The world has traffic, pedestrians and buildings. Crashes dent the car and raise the damage percentage. A repair costs ₹50. The HUD shows an analog speedometer (0 to 260 km/h), a rev bar and a minimap. Waves move on the sea, and you can hear the sea when you are near the water.

### Taxi mission

Ride requests appear while you drive, in both Open World and Mission mode. Each request shows the passenger's name, the distance, the destination and the fare. Press **Accept** to take it. Pick up the passenger, drive to the destination, and you are paid when you arrive. The fare is ₹20 per km, up to ₹1000 for a 50 km ride. Every passenger has a different destination.

### Tuning

You can change the car colour with the colour picker. Engine upgrades are shown below.

| Engine | Power | Torque | Price |
|---|---|---|---|
| V6 (start) | 300 hp | 400 Nm | free |
| V8 | 460 hp | 550 Nm | ₹300 |
| V10 | 560 hp | 650 Nm | ₹600 |
| V12 | 660 hp | 780 Nm | ₹1000 |
| W16 | 900 hp | 1100 Nm | ₹1500 |

Turbo stages add power and torque on top of the engine: Turbo 1 is +20 hp and +40 Nm for ₹200, Turbo 2 is +40 hp and +80 Nm for ₹400, and Turbo 3 is +80 hp and +160 Nm for ₹800. Your money and tuning are saved in the browser.

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| Accelerate | W or ↑ | Gas pedal |
| Brake / reverse | S or ↓ | Brake pedal |
| Steer | A or ← and D or → | Drag the steering wheel (full turn in both directions) |
| Gears | 0 to 6 (0 is neutral), R for reverse, E to shift up, Q to shift down | Slide the gear lever |
| Camera | C | 📷 button |
| Day / night | N | 🌙 button |
| Weather | G | ☁ button |
| Sport mode | none | SPORT button |
| Drift mode | none | DRIFT button |
| Fullscreen | F | ⛶ button |

A gamepad has basic support for steering, gas, brake, gears and camera.

## Run it locally

1. Download `index.html`.
2. Double-click it, or open it in Chrome, Edge, Firefox or Safari.
3. You need an internet connection, because the 3D library loads from `cdnjs.cloudflare.com`. Your browser also needs WebGL support.

The best experience is on a desktop or laptop with a keyboard, or on a phone held in landscape mode.

## Put it on GitHub

1. Create a new repository on GitHub, for example `m5-open-world`, and set it to **Public**.
2. Upload `index.html`, `README.md` and `LICENSE` with the GitHub web upload, or use git:

```bash
git init
git add .
git commit -m "First release: M5 Open World prototype"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

3. To play the game online, open **Settings → Pages**, choose **Deploy from a branch**, select **main** and **/ (root)**, and click **Save**. After a minute or two, the game is live at `https://<your-username>.github.io/<your-repo>/`.

## Roadmap

These features are planned but are not in this version yet.

| Feature | Status |
|---|---|
| Airports and airplanes that take off and land | Planned |
| Train tracks, railway stations and trains | Planned |
| Flyovers and bridges | Planned |
| A large dedicated forest area (currently forest is only in the south) | Planned |
| Highways between cities, dead-end roads and road networks | Planned |
| City names on the HUD (currently it shows a generic "City" label) | Planned |

## Known limitations

Performance depends on the device. Phones may run slower, because the terrain is rebuilt as you move. The car is a simplified model made from basic shapes, and the physics are arcade-style rather than a full simulation.

## Contributing

Issues and suggestions are welcome. Please open an issue to report a bug or to request a feature.

## Credits

Built with [three.js](https://threejs.org/), which is released under the MIT License.

## License

This project is released under the MIT License. See [LICENSE](LICENSE).

## Disclaimer

This is an unofficial fan project. BMW and M5 are trademarks of BMW AG. This project is not affiliated with, endorsed by or sponsored by BMW AG. The car in the game is an original, simplified model.
